# KNN
#
# This is an example function named 'KNN'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

KNN=function(X_train,X_test,y_train,K){
  #计算距离
  judge1=function(X_tr,Z){
    c=c(1:length(X_tr[,1]))
    for(i in 1:length(X_tr[,1])){
      c[i]=distance(X_tr[i,],Z)
    }
    return(c)
  }
  #识别函数
  judge2=function(c,k,Y){
    t=0
    cn=sort(c)
    for(i in 1:k){
      for(j in 1:length(c)){
        if(cn[i]==c[j]){
          t=t+Y[j]
          break
        }
      }
    }
    t=t/k
    return(t)
  }
  zscore=function(X_tr,X_te){
    r=length(X_tr[,1])
    c=length(X_tr[1,])
    XX=apply(X_tr,2,mean)#矩阵按列取平均
    XXX=matrix(XX,nrow=r,ncol=c,byrow=TRUE) #把XX按列生成r*c的矩阵
    #YYY=matrix(XX,nrow=length(X_te[,1]),ncol=length(X_te[1,]),byrow=TRUE)
    a=var(X_tr)
    cc=c()
    for(i in 1:c){
      cc[i]=sqrt(a[i,i])
    }
    A=matrix(cc,nrow=r,ncol=c,byrow=TRUE)
    #B=matrix(cc,nrow=length(X_te[,1]),ncol=length(X_te[1,]),byrow=TRUE)
    X=(X_tr-XXX)/A
    Y=(X_te-XX)/cc
    return(list(X,Y))
  }
  distance=function(a,b){
    t=0
    for(i in 1:4){
      t=(a[i]-b[i])^2+t
    }
    return(sqrt(t))
  }
  a=zscore(X_train,X_test)#标准化
  x1=a[1]
  x2=a[2]
  X_tr=x1[[1]]
  X_te=x2[[1]]
  c=judge1(X_tr,X_te)
  t=judge2(c,K,y_train)
  return(t)
}

